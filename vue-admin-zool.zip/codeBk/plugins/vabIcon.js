import Vue from 'vue'
import VabIcon from 'vab-icon'

Vue.component('VabIcon', VabIcon)
