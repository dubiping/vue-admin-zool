<template>
  <div>page permission</div>
</template>
<script>
export default {
  name: 'PagePermission'
}
</script>
