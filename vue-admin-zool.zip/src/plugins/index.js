import Vue from 'vue'
import 'normalize.css/normalize.css'
import './element'
import '@/icons'
import '@/routerGuard'

import Global from '@/utils/global'

Vue.use(Global)
